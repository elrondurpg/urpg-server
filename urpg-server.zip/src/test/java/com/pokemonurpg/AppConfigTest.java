package com.pokemonurpg;

import org.junit.Test;
import org.springframework.test.context.TestPropertySource;

import static org.junit.Assert.*;

public class AppConfigTest {
    private final static String SERVER_IMAGE_BASE = "SERVER_IMAGE_BASE";


}