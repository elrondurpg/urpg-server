package com.pokemonurpg;

public class View {

    public static interface MemberView {

        public static interface Summary {

        }

        public static interface Pokemon extends Summary {

        }
    }

}
