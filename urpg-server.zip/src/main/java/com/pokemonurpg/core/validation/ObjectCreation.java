package com.pokemonurpg.core.validation;

public interface ObjectCreation {
}
