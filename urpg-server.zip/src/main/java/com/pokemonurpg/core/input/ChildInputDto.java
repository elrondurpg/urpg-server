package com.pokemonurpg.core.input;

public class ChildInputDto {
    private Boolean delete = false;

    public Boolean getDelete() {
        return delete;
    }

    public void setDelete(Boolean delete) {
        this.delete = delete;
    }
}
