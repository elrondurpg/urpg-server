package com.pokemonurpg.strings;

public class ErrorStrings {
    public static final String ERROR_00000 = "Error 00000 - Invalid request data";
    public static final String ERROR_00002 = "Error 00002 - Current user is not logged on or does not have permissions to perform the requested action.";
}
